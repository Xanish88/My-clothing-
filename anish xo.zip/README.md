# Minimalist Website — Quick Start (for absolute beginners)

This bundle is a **ready-made static website** you can publish to the internet without knowing how to code.
It includes:
- `index.html` — the webpage
- `styles.css` — styling
- `README.md` — what you are reading now
- `payment-integration.md` — how to accept payments (local & international)

---

## Super-easy steps to make it live (no terminal, no code required)

### 1) Create accounts (do these first)
1. Create a **GitHub** account: https://github.com/join  
2. Create a **Vercel** account: https://vercel.com (use "Sign up with GitHub")

### 2) Upload the files to GitHub (like uploading photos)
1. Go to GitHub → click **New** repository → give it a name (example: `goddess-site`) → Create repository.
2. In the new repo page click **Add file → Upload files**.
3. Drag the files from this ZIP (index.html, styles.css, README.md, payment-integration.md) into GitHub and click **Commit changes**.

### 3) Publish to the web on Vercel (one click)
1. Open https://vercel.com and log in (connect GitHub when asked).
2. Click **New Project → Import from GitHub** and pick the repository you just uploaded.
3. Click **Deploy**. Wait 1–2 minutes. Vercel will give you a link like `https://goddess-site.vercel.app` — that's your live website.

### 4) Make the buttons accept real payments (very important)
Open the file `index.html` in the GitHub repo (you can edit on GitHub by clicking the file, then the pencil icon to edit).
Find the text `#REPLACE_WITH_KHALTI_LINK` and `#REPLACE_WITH_INTERNATIONAL_LINK`.

- For Nepali customers: sign up for **Khalti** (https://khalti.com/merchant/) or **eSewa** (https://esewa.com.np/) and create a merchant account. From their dashboard you can create *payment links* or get integration keys. Copy the payment link they give you and paste it in place of `#REPLACE_WITH_KHALTI_LINK`.

- For international customers: many international gateways (Stripe, PayPal) have country restrictions — see `payment-integration.md` for details and links. If PayPal/Stripe are not available for Nepali merchants, you can use marketplace/third-party services to accept international cards.

After replacing links, commit changes. Vercel will automatically update the live site.

---

## If you want me to do this for you
I can prepare the GitHub repo content and give you the files ready to upload, or I can give exact copy-paste payment-link values once you create a Khalti/eSewa merchant account. Tell me which you want and I will prepare it for you.

