# Payment options explained (simple)

## For customers inside Nepal (recommended)
Use Nepali payment gateways:
- **Khalti** — supports web integration, wallets, mobile banking, and cards. You create a *merchant account* and can get test/live keys or payment links. Docs: https://docs.khalti.com/ and https://khalti.com/merchant/ . cite[khalti]
- **eSewa** — provides ePay for merchants; you can receive payments from eSewa users. Docs: https://developer.esewa.com.np/ . cite[esewa]
- **IME Pay** — another wallet with merchant integration. Docs: https://developer.imepay.com.np/ . cite[imepay]

**How it works (very simple):**
1. You sign up as a merchant on Khalti/eSewa/IME Pay and provide business documents.
2. In their dashboard, you either create a payment link or get "API keys".
3. If you use a payment link: paste that link into the `href` of "Pay (Nepal)" buttons in `index.html`. When a customer clicks it, they complete payment on Khalti/eSewa, and money goes to your merchant account.

## For international customers (cards)
- **Stripe** is the usual choice for global card payments, but Stripe does not support merchants in every country. Check Stripe's global page: https://stripe.com/global . cite[stripe]
- **PayPal** is available in many countries, but its capabilities (sending vs receiving) differ by country. In Nepal, receiving via PayPal to local banks may be limited. See notes: https://www.paypal.com/ and local guides. cite[paypal,bnr]

If Stripe or PayPal are not available for your business in Nepal, you have options:
- Use **third-party marketplaces** (Gumroad, Etsy) or platforms that accept international cards and pay you by bank transfer/payoneer.
- Use a service like **TransFi** which offers borderless payment collection for Nepali businesses. (https://www.transfi.com/) cite[transfi]

## Summary (what I recommend first)
1. Start with **Khalti** or **eSewa** to accept payments from Nepali customers (fastest and easiest for Nepal). Khalti has simple docs and payment links. cite[khalti,esewa]
2. For international buyers later, either set up a marketplace (Gumroad) or explore TransFi / registering a foreign company for Stripe (advanced).

